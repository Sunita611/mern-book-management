import React, { useState, useEffect } from "react";
import axios from "axios";
import "./App.css";

function App() {

const [books,setBooks] = useState([]);
const [title,setTitle] = useState("");
const [author,setAuthor] = useState("");
const [price,setPrice] = useState("");

useEffect(()=>{
fetchBooks();
},[]);

const fetchBooks = async ()=>{
const res = await axios.get("http://localhost:8000/books");
setBooks(res.data);
};

const addBook = async ()=>{
await axios.post("http://localhost:8000/books",{
title,
author,
price
});

setTitle("");
setAuthor("");
setPrice("");

fetchBooks();
};

const deleteBook = async(id)=>{
await axios.delete(`http://localhost:8000/books/${id}`);
fetchBooks();
};

return(

<div className="container">

<h1>Book Management System</h1>

<h2>Add Book</h2>

<input
placeholder="Title"
value={title}
onChange={(e)=>setTitle(e.target.value)}
/>

<input
placeholder="Author"
value={author}
onChange={(e)=>setAuthor(e.target.value)}
/>

<input
placeholder="Price"
value={price}
onChange={(e)=>setPrice(e.target.value)}
/>

<button onClick={addBook}>Add Book</button>

<h2>Books List</h2>

{books.map((book)=>(
<div className="bookCard" key={book._id}>

<h3>{book.title}</h3>

<p>Author: {book.author}</p>

<p>Price: ₹{book.price}</p>

<button onClick={()=>deleteBook(book._id)}>
Delete
</button>

</div>
))}

</div>

);

}

export default App;