const express = require("express")
const router = express.Router()
const Book = require("../models/Book")

// Add book
router.post("/add", async (req,res)=>{
 const newBook = new Book(req.body)
 await newBook.save()
 res.json(newBook)
})

// Get all books
router.get("/", async (req,res)=>{
 const books = await Book.find()
 res.json(books)
})

// Delete book
router.delete("/:id", async (req,res)=>{
 await Book.findByIdAndDelete(req.params.id)
 res.json("Book deleted")
})

module.exports = router